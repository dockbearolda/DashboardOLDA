--
-- PostgreSQL database dump
--

\restrict uGdHfOPWYcEPlokrcejyi8qO4fZyldwLmnPe6kIuc09AYnM34m7POUFxtXSlKfd

-- Dumped from database version 16.11 (Ubuntu 16.11-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.11 (Ubuntu 16.11-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: OrderStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."OrderStatus" AS ENUM (
    'COMMANDE_A_TRAITER',
    'COMMANDE_EN_ATTENTE',
    'COMMANDE_A_PREPARER',
    'MAQUETTE_A_FAIRE',
    'PRT_A_FAIRE',
    'EN_ATTENTE_VALIDATION',
    'EN_COURS_IMPRESSION',
    'PRESSAGE_A_FAIRE',
    'CLIENT_A_CONTACTER',
    'CLIENT_PREVENU',
    'ARCHIVES'
);


--
-- Name: PaymentStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PaymentStatus" AS ENUM (
    'PENDING',
    'PAID',
    'FAILED',
    'REFUNDED'
);


--
-- Name: PlanningPriority; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PlanningPriority" AS ENUM (
    'BASSE',
    'MOYENNE',
    'HAUTE'
);


--
-- Name: PlanningStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PlanningStatus" AS ENUM (
    'A_DEVISER',
    'ATTENTE_VALIDATION',
    'MAQUETTE_A_FAIRE',
    'ATTENTE_MARCHANDISE',
    'A_PREPARER',
    'A_PRODUIRE',
    'EN_PRODUCTION',
    'A_MONTER_NETTOYER',
    'MANQUE_INFORMATION',
    'TERMINE',
    'PREVENIR_CLIENT',
    'CLIENT_PREVENU',
    'RELANCE_CLIENT',
    'PRODUIT_RECUPERE',
    'A_FACTURER',
    'FACTURE_FAITE'
);


--
-- Name: WorkflowListType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."WorkflowListType" AS ENUM (
    'ACHAT',
    'STANDARD',
    'ATELIER',
    'DTF'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: dtf_rows; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dtf_rows (
    id text NOT NULL,
    "user" text NOT NULL,
    name text DEFAULT ''::text NOT NULL,
    status text DEFAULT 'en_cours'::text NOT NULL,
    problem text,
    "position" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: order_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.order_items (
    id text NOT NULL,
    "orderId" text NOT NULL,
    famille text,
    couleur text,
    "tailleDTF" text,
    "positionLogo" text,
    reference text,
    taille text,
    collection text,
    "imageAvant" text,
    "imageArriere" text,
    "noteClient" text,
    "positionNote" text,
    "prtRef" text,
    "prtTaille" text,
    "prtQuantite" integer,
    "prixUnitaire" double precision DEFAULT 0 NOT NULL
);


--
-- Name: orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.orders (
    id text NOT NULL,
    "orderNumber" text NOT NULL,
    "customerName" text NOT NULL,
    "customerFirstName" text,
    "customerEmail" text NOT NULL,
    "customerPhone" text,
    "customerAddress" text,
    status public."OrderStatus" DEFAULT 'COMMANDE_A_TRAITER'::public."OrderStatus" NOT NULL,
    "paymentStatus" public."PaymentStatus" DEFAULT 'PENDING'::public."PaymentStatus" NOT NULL,
    total double precision NOT NULL,
    subtotal double precision NOT NULL,
    shipping double precision DEFAULT 0 NOT NULL,
    tax double precision DEFAULT 0 NOT NULL,
    currency text DEFAULT 'EUR'::text NOT NULL,
    notes text,
    category text DEFAULT ''::text NOT NULL,
    deadline timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: person_notes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.person_notes (
    id text NOT NULL,
    person text NOT NULL,
    content text DEFAULT ''::text NOT NULL,
    todos jsonb DEFAULT '[]'::jsonb NOT NULL,
    "updatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: planning_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.planning_items (
    id text NOT NULL,
    priority public."PlanningPriority" DEFAULT 'MOYENNE'::public."PlanningPriority" NOT NULL,
    "clientName" text DEFAULT ''::text NOT NULL,
    quantity double precision DEFAULT 1 NOT NULL,
    designation text DEFAULT ''::text NOT NULL,
    note text DEFAULT ''::text NOT NULL,
    "unitPrice" double precision DEFAULT 0 NOT NULL,
    deadline timestamp(3) without time zone,
    status public."PlanningStatus" DEFAULT 'A_DEVISER'::public."PlanningStatus" NOT NULL,
    responsible text DEFAULT ''::text NOT NULL,
    color text DEFAULT ''::text NOT NULL,
    "position" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: prt_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.prt_requests (
    id text NOT NULL,
    "clientName" text NOT NULL,
    dimensions text NOT NULL,
    design text NOT NULL,
    color text NOT NULL,
    quantity integer DEFAULT 1 NOT NULL,
    done boolean DEFAULT false NOT NULL,
    "position" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: user_profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_profiles (
    id text NOT NULL,
    "userId" text NOT NULL,
    "profilePhotoLink" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: workflow_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.workflow_items (
    id text NOT NULL,
    "listType" public."WorkflowListType" NOT NULL,
    title text NOT NULL,
    "position" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Data for Name: dtf_rows; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dtf_rows (id, "user", name, status, problem, "position", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: order_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.order_items (id, "orderId", famille, couleur, "tailleDTF", "positionLogo", reference, taille, collection, "imageAvant", "imageArriere", "noteClient", "positionNote", "prtRef", "prtTaille", "prtQuantite", "prixUnitaire") FROM stdin;
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.orders (id, "orderNumber", "customerName", "customerFirstName", "customerEmail", "customerPhone", "customerAddress", status, "paymentStatus", total, subtotal, shipping, tax, currency, notes, category, deadline, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: person_notes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.person_notes (id, person, content, todos, "updatedAt") FROM stdin;
\.


--
-- Data for Name: planning_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.planning_items (id, priority, "clientName", quantity, designation, note, "unitPrice", deadline, status, responsible, color, "position", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: prt_requests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.prt_requests (id, "clientName", dimensions, design, color, quantity, done, "position", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: user_profiles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_profiles (id, "userId", "profilePhotoLink", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: workflow_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.workflow_items (id, "listType", title, "position", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Name: dtf_rows dtf_rows_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dtf_rows
    ADD CONSTRAINT dtf_rows_pkey PRIMARY KEY (id);


--
-- Name: order_items order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT order_items_pkey PRIMARY KEY (id);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: person_notes person_notes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.person_notes
    ADD CONSTRAINT person_notes_pkey PRIMARY KEY (id);


--
-- Name: planning_items planning_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.planning_items
    ADD CONSTRAINT planning_items_pkey PRIMARY KEY (id);


--
-- Name: prt_requests prt_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.prt_requests
    ADD CONSTRAINT prt_requests_pkey PRIMARY KEY (id);


--
-- Name: user_profiles user_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_profiles
    ADD CONSTRAINT user_profiles_pkey PRIMARY KEY (id);


--
-- Name: workflow_items workflow_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.workflow_items
    ADD CONSTRAINT workflow_items_pkey PRIMARY KEY (id);


--
-- Name: dtf_rows_user_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dtf_rows_user_idx ON public.dtf_rows USING btree ("user");


--
-- Name: orders_orderNumber_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "orders_orderNumber_key" ON public.orders USING btree ("orderNumber");


--
-- Name: person_notes_person_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX person_notes_person_key ON public.person_notes USING btree (person);


--
-- Name: prt_requests_done_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX prt_requests_done_idx ON public.prt_requests USING btree (done);


--
-- Name: user_profiles_userId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "user_profiles_userId_key" ON public.user_profiles USING btree ("userId");


--
-- Name: workflow_items_listType_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "workflow_items_listType_idx" ON public.workflow_items USING btree ("listType");


--
-- Name: order_items order_items_orderId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.order_items
    ADD CONSTRAINT "order_items_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES public.orders(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict uGdHfOPWYcEPlokrcejyi8qO4fZyldwLmnPe6kIuc09AYnM34m7POUFxtXSlKfd

